import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/primary_button.dart';
import '../../main.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});
  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _branch = TextEditingController();
  final _year = TextEditingController();
  final _company = TextEditingController();
  String _role = 'junior';
  bool _loading = false;

  Future<void> _signup() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await AuthService().signUp(
        name: _name.text.trim(),
        email: _email.text.trim(),
        password: _password.text,
        role: _role,
        branch: _branch.text.trim(),
        year: _year.text.trim(),
        company: _role == 'senior' ? _company.text.trim() : null,
      );
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context, MaterialPageRoute(builder: (_) => const AuthGate()), (_) => false);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Widget _roleChip(String value, String label, IconData icon) {
    final selected = _role == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _role = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          margin: EdgeInsets.only(left: value == 'senior' ? 8 : 0, right: value == 'junior' ? 8 : 0),
          decoration: BoxDecoration(
            color: selected ? AppTheme.primary : AppTheme.surface,
            border: Border.all(color: selected ? AppTheme.primary : AppTheme.border),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(children: [
            Icon(icon, color: selected ? Colors.white : AppTheme.primary),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    color: selected ? Colors.white : AppTheme.textDark,
                    fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create account')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: AppTheme.shadowedCard,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('I am a', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Row(children: [
                    _roleChip('junior', 'Junior', Icons.school_outlined),
                    _roleChip('senior', 'Senior', Icons.workspace_premium_outlined),
                  ]),
                  const SizedBox(height: 20),
                  TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Full name'), validator: Validators.notEmpty),
                  const SizedBox(height: 12),
                  TextFormField(controller: _email, decoration: const InputDecoration(labelText: 'Email'), validator: Validators.email),
                  const SizedBox(height: 12),
                  TextFormField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'Password'), validator: Validators.password),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: TextFormField(controller: _branch, decoration: const InputDecoration(labelText: 'Branch'))),
                    const SizedBox(width: 12),
                    Expanded(child: TextFormField(controller: _year, decoration: const InputDecoration(labelText: 'Year'))),
                  ]),
                  if (_role == 'senior') ...[
                    const SizedBox(height: 12),
                    TextFormField(controller: _company, decoration: const InputDecoration(labelText: 'Company placed at')),
                  ],
                  const SizedBox(height: 20),
                  PrimaryButton(label: 'Create account', loading: _loading, onPressed: _signup),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
