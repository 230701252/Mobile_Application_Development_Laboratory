import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../models/material_model.dart';
import '../../widgets/material_card.dart';
import '../common/chat_list_screen.dart';
import '../common/notifications_screen.dart';
import '../common/connections_screen.dart';
import '../common/profile_screen.dart';
import '../junior/material_detail_screen.dart';
import 'upload_material_screen.dart';
import 'share_experience_screen.dart';

class SeniorHome extends StatefulWidget {
  const SeniorHome({super.key});
  @override
  State<SeniorHome> createState() => _SeniorHomeState();
}

class _SeniorHomeState extends State<SeniorHome> {
  int _idx = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const _SeniorDashboard(),
      const ChatListScreen(),
      const NotificationsScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      body: pages[_idx],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_outlined), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: 'Chats'),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_outlined), label: 'Alerts'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
      floatingActionButton: _idx == 0
          ? FloatingActionButton.extended(
              backgroundColor: AppTheme.primary,
              icon: const Icon(Icons.upload_file, color: Colors.white),
              label: const Text('Upload', style: TextStyle(color: Colors.white)),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const UploadMaterialScreen())),
            )
          : null,
    );
  }
}

class _SeniorDashboard extends StatelessWidget {
  const _SeniorDashboard();

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final user = FirebaseAuth.instance.currentUser!;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Welcome,', style: TextStyle(color: AppTheme.textMuted, fontSize: 14)),
          Text(user.displayName ?? 'Senior',
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),

          // Stats
          Row(children: [
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirestoreService().materialsByUser(uid),
                builder: (_, s) => _StatCard(
                  icon: Icons.upload_file,
                  label: 'Uploads',
                  value: '${s.data?.docs.length ?? 0}',
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirestoreService().connections(uid),
                builder: (_, s) => _StatCard(
                  icon: Icons.people_outline,
                  label: 'Connections',
                  value: '${s.data?.docs.length ?? 0}',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ConnectionsScreen())),
                ),
              ),
            ),
          ]),

          const SizedBox(height: 16),

          // Actions
          Row(children: [
            Expanded(
              child: _ActionCard(
                icon: Icons.lightbulb_outline,
                label: 'Share experience',
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ShareExperienceScreen())),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ActionCard(
                icon: Icons.people_outline,
                label: 'Connections',
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ConnectionsScreen())),
              ),
            ),
          ]),

          const SizedBox(height: 24),
          const Text('Your uploads',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),

          StreamBuilder<QuerySnapshot>(
            stream: FirestoreService().materialsByUser(uid),
            builder: (context, snap) {
              if (!snap.hasData) return const Padding(
                padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
              final docs = snap.data!.docs;
              if (docs.isEmpty) {
                return Container(
                  padding: const EdgeInsets.all(20),
                  decoration: AppTheme.shadowedCard,
                  child: const Text('No uploads yet. Tap the Upload button to share materials.',
                      style: TextStyle(color: AppTheme.textMuted)),
                );
              }
              return Column(
                children: docs.map((d) {
                  final m = MaterialModel.fromDoc(d);
                  return MaterialCard(
                    material: m,
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => MaterialDetailScreen(material: m),
                    )),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final VoidCallback? onTap;
  const _StatCard({required this.icon, required this.label, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.shadowedCard,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppTheme.primary),
            const SizedBox(height: 12),
            Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            Text(label, style: const TextStyle(color: AppTheme.textMuted)),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ActionCard({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.shadowedCard,
        child: Row(children: [
          Icon(icon, color: AppTheme.primary),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
          const Icon(Icons.chevron_right, color: AppTheme.textMuted),
        ]),
      ),
    );
  }
}
