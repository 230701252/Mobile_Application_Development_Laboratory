import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/primary_button.dart';

class ShareExperienceScreen extends StatefulWidget {
  const ShareExperienceScreen({super.key});
  @override
  State<ShareExperienceScreen> createState() => _ShareExperienceScreenState();
}

class _ShareExperienceScreenState extends State<ShareExperienceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _company = TextEditingController();
  final _desc = TextEditingController();
  bool _loading = false;

  Future<void> _share() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      await FirestoreService().addMaterial({
        'title': _title.text.trim(),
        'description': _desc.text.trim(),
        'company': _company.text.trim(),
        'tags': ['experience'],
        'fileUrl': '',
        'fileName': '',
        'uploaderId': user.uid,
        'uploaderName': user.displayName ?? 'Senior',
        'likes': <String>[],
        'commentCount': 0,
      });
      if (!mounted) return;
      Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Share experience')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: AppTheme.shadowedCard,
            child: Column(children: [
              TextFormField(controller: _title, decoration: const InputDecoration(labelText: 'Title'), validator: Validators.notEmpty),
              const SizedBox(height: 12),
              TextFormField(controller: _company, decoration: const InputDecoration(labelText: 'Company')),
              const SizedBox(height: 12),
              TextFormField(controller: _desc, maxLines: 8, decoration: const InputDecoration(labelText: 'Your placement story'), validator: Validators.notEmpty),
              const SizedBox(height: 20),
              PrimaryButton(label: 'Share', loading: _loading, onPressed: _share),
            ]),
          ),
        ),
      ),
    );
  }
}
