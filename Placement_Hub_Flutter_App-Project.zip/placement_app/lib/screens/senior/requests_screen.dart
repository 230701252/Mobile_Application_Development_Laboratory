// Wrapper alias for notifications screen, since requests are notifications
export '../common/notifications_screen.dart';
