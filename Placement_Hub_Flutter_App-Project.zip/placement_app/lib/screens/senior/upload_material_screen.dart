import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/primary_button.dart';

class UploadMaterialScreen extends StatefulWidget {
  const UploadMaterialScreen({super.key});
  @override
  State<UploadMaterialScreen> createState() => _UploadMaterialScreenState();
}

class _UploadMaterialScreenState extends State<UploadMaterialScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _company = TextEditingController();
  final _tag = TextEditingController();
  File? _file;
  bool _loading = false;

  Future<void> _pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (r != null) setState(() => _file = File(r.files.single.path!));
  }

  Future<void> _upload() async {
    if (!_formKey.currentState!.validate()) return;
    if (_file == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a PDF')));
      return;
    }
    setState(() => _loading = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final upload = await StorageService().uploadPdf(_file!, user.uid);
      await FirestoreService().addMaterial({
        'title': _title.text.trim(),
        'description': _desc.text.trim(),
        'company': _company.text.trim(),
        'tags': _tag.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
        'fileUrl': upload['url'],
        'fileName': upload['name'],
        'uploaderId': user.uid,
        'uploaderName': user.displayName ?? 'Senior',
        'likes': <String>[],
        'commentCount': 0,
      });
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Uploaded successfully!')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload material')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: AppTheme.shadowedCard,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                GestureDetector(
                  onTap: _pick,
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppTheme.border, style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(12),
                      color: AppTheme.background,
                    ),
                    child: Column(children: [
                      const Icon(Icons.cloud_upload_outlined, size: 40, color: AppTheme.primary),
                      const SizedBox(height: 8),
                      Text(_file == null ? 'Tap to select a PDF' : _file!.path.split('/').last,
                          textAlign: TextAlign.center, style: const TextStyle(color: AppTheme.textMuted)),
                    ]),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(controller: _title, decoration: const InputDecoration(labelText: 'Title'), validator: Validators.notEmpty),
                const SizedBox(height: 12),
                TextFormField(controller: _desc, maxLines: 3, decoration: const InputDecoration(labelText: 'Description'), validator: Validators.notEmpty),
                const SizedBox(height: 12),
                TextFormField(controller: _company, decoration: const InputDecoration(labelText: 'Company / Topic')),
                const SizedBox(height: 12),
                TextFormField(controller: _tag, decoration: const InputDecoration(labelText: 'Tags (comma separated)')),
                const SizedBox(height: 20),
                PrimaryButton(label: 'Upload', loading: _loading, onPressed: _upload),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
