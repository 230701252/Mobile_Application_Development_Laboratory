import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/primary_button.dart';

class SeniorProfileScreen extends StatelessWidget {
  final String uid;
  const SeniorProfileScreen({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirestoreService().getUser(uid),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final u = snap.data!.data() as Map<String, dynamic>? ?? {};
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: AppTheme.shadowedCard,
                child: Column(children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: AppTheme.primary.withOpacity(0.1),
                    child: Text((u['name'] ?? 'U').toString()[0].toUpperCase(),
                        style: const TextStyle(fontSize: 28, color: AppTheme.primary, fontWeight: FontWeight.w800)),
                  ),
                  const SizedBox(height: 12),
                  Text(u['name'] ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  Text('${u['role'] ?? ''} • ${u['branch'] ?? ''}',
                      style: const TextStyle(color: AppTheme.textMuted)),
                  if ((u['company'] ?? '').toString().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text('Placed at ${u['company']}',
                        style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w600)),
                  ],
                  const SizedBox(height: 16),
                  PrimaryButton(
                    label: 'Send connect request',
                    onPressed: () async {
                      await FirestoreService().sendRequest(uid, u['name'] ?? '');
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Request sent!')));
                    },
                  ),
                ]),
              ),
            ],
          );
        },
      ),
    );
  }
}
