import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../models/material_model.dart';
import '../../widgets/material_card.dart';
import '../../widgets/empty_state.dart';
import '../common/chat_list_screen.dart';
import '../common/notifications_screen.dart';
import '../common/connections_screen.dart';
import '../common/profile_screen.dart';
import 'material_detail_screen.dart';

class JuniorHome extends StatefulWidget {
  const JuniorHome({super.key});
  @override
  State<JuniorHome> createState() => _JuniorHomeState();
}

class _JuniorHomeState extends State<JuniorHome> {
  int _idx = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const _JuniorFeed(),
      const ConnectionsScreen(),
      const ChatListScreen(),
      const NotificationsScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      body: pages[_idx],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), label: 'Explore'),
          BottomNavigationBarItem(icon: Icon(Icons.people_outline), label: 'Connect'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: 'Chats'),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_outlined), label: 'Alerts'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class _JuniorFeed extends StatefulWidget {
  const _JuniorFeed();
  @override
  State<_JuniorFeed> createState() => _JuniorFeedState();
}

class _JuniorFeedState extends State<_JuniorFeed> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Explore materials',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              const Text('Learn from those who made it.',
                  style: TextStyle(color: AppTheme.textMuted)),
              const SizedBox(height: 16),
              TextField(
                onChanged: (v) => setState(() => _query = v.toLowerCase()),
                decoration: const InputDecoration(
                  hintText: 'Search by title, company or tag',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
            ]),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirestoreService().materialsStream(),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                var docs = snap.data!.docs;
                if (_query.isNotEmpty) {
                  docs = docs.where((d) {
                    final m = d.data() as Map<String, dynamic>;
                    final hay = '${m['title']} ${m['company']} ${(m['tags'] ?? []).join(' ')}'.toLowerCase();
                    return hay.contains(_query);
                  }).toList();
                }
                if (docs.isEmpty) {
                  return const EmptyState(icon: Icons.inbox_outlined, title: 'No materials found');
                }
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: docs.length,
                  itemBuilder: (context, i) {
                    final m = MaterialModel.fromDoc(docs[i]);
                    return MaterialCard(
                      material: m,
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => MaterialDetailScreen(material: m),
                      )),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
