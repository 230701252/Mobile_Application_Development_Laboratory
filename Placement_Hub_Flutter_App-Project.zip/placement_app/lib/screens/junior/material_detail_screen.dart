import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../models/material_model.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';
import '../../theme/app_theme.dart';
import 'senior_profile_screen.dart';

class MaterialDetailScreen extends StatefulWidget {
  final MaterialModel material;
  const MaterialDetailScreen({super.key, required this.material});

  @override
  State<MaterialDetailScreen> createState() => _MaterialDetailScreenState();
}

class _MaterialDetailScreenState extends State<MaterialDetailScreen> {
  final _comment = TextEditingController();
  bool _downloading = false;

  Future<void> _download() async {
    if (widget.material.fileUrl.isEmpty) return;
    setState(() => _downloading = true);
    try {
      final f = await StorageService().downloadPdf(widget.material.fileUrl, widget.material.fileName);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved to ${f.path}')));
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.material;
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Material')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: AppTheme.shadowedCard,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => SeniorProfileScreen(uid: m.uploaderId),
                )),
                child: Row(children: [
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: AppTheme.primary.withOpacity(0.1),
                    child: Text(m.uploaderName.isNotEmpty ? m.uploaderName[0].toUpperCase() : '?',
                        style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(width: 8),
                  Text(m.uploaderName, style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (m.company.isNotEmpty) ...[
                    const Text(' • '),
                    Text(m.company, style: const TextStyle(color: AppTheme.textMuted)),
                  ],
                ]),
              ),
              const SizedBox(height: 16),
              Text(m.description, style: const TextStyle(height: 1.5)),
            ]),
          ),
          const SizedBox(height: 12),

          // Action row
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: AppTheme.shadowedCard,
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              _act(Icons.favorite, m.likes.contains(uid) ? Colors.red : AppTheme.textMuted, '${m.likes.length}',
                  () => FirestoreService().toggleLike(m.id, uid)),
              _act(Icons.bookmark_outline, AppTheme.textMuted, 'Save',
                  () => FirestoreService().toggleSave(m.id)),
              _act(Icons.share_outlined, AppTheme.textMuted, 'Share',
                  () => Share.share('Check out: ${m.title}\n${m.fileUrl}')),
              if (m.fileUrl.isNotEmpty)
                _act(_downloading ? Icons.hourglass_top : Icons.download_outlined,
                    AppTheme.textMuted, 'Download', _download),
              if (m.fileUrl.isNotEmpty)
                _act(Icons.open_in_new, AppTheme.textMuted, 'View',
                    () => launchUrl(Uri.parse(m.fileUrl), mode: LaunchMode.externalApplication)),
            ]),
          ),

          const SizedBox(height: 20),
          const Text('Comments', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 8),

          Container(
            decoration: AppTheme.shadowedCard,
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _comment,
                  decoration: const InputDecoration(hintText: 'Add a comment...'),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send, color: AppTheme.primary),
                onPressed: () {
                  if (_comment.text.trim().isEmpty) return;
                  FirestoreService().addComment(m.id, _comment.text.trim());
                  _comment.clear();
                },
              ),
            ]),
          ),

          const SizedBox(height: 12),
          StreamBuilder<QuerySnapshot>(
            stream: FirestoreService().commentsStream(m.id),
            builder: (context, snap) {
              if (!snap.hasData) return const SizedBox();
              return Column(
                children: snap.data!.docs.map((d) {
                  final c = d.data() as Map<String, dynamic>;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(14),
                    decoration: AppTheme.shadowedCard,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(c['userName'] ?? 'User',
                          style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.primary)),
                      const SizedBox(height: 4),
                      Text(c['text'] ?? ''),
                    ]),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _act(IconData icon, Color color, String label, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(color: color, fontSize: 11)),
          ]),
        ),
      );
}
