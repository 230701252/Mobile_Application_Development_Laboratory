import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/empty_state.dart';
import 'chat_screen.dart';

class ConnectionsScreen extends StatelessWidget {
  const ConnectionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Connections')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirestoreService().connections(uid),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const EmptyState(icon: Icons.people_outline, title: 'No connections yet');
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final otherId = docs[i].id;
              return FutureBuilder<DocumentSnapshot>(
                future: FirestoreService().getUser(otherId),
                builder: (context, userSnap) {
                  if (!userSnap.hasData) return const SizedBox(height: 80);
                  final u = userSnap.data!.data() as Map<String, dynamic>? ?? {};
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: AppTheme.shadowedCard,
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: AppTheme.primary.withOpacity(0.1),
                        child: Text((u['name'] ?? 'U').toString()[0].toUpperCase(),
                            style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
                      ),
                      title: Text(u['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${u['role'] ?? ''} • ${u['branch'] ?? ''}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.chat_bubble_outline, color: AppTheme.primary),
                        onPressed: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => ChatScreen(otherUid: otherId, otherName: u['name'] ?? ''),
                        )),
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
