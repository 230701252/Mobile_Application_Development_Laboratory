import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import '../auth/login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(user.uid).get(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final data = snap.data!.data() as Map<String, dynamic>? ?? {};
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: AppTheme.shadowedCard,
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 44,
                      backgroundColor: AppTheme.primary.withOpacity(0.1),
                      child: Text(
                        (data['name'] ?? 'U').toString().substring(0, 1).toUpperCase(),
                        style: const TextStyle(fontSize: 32, color: AppTheme.primary, fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(data['name'] ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                    Text(data['email'] ?? '', style: const TextStyle(color: AppTheme.textMuted)),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.primary,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text((data['role'] ?? '').toString().toUpperCase(),
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                decoration: AppTheme.shadowedCard,
                child: Column(children: [
                  _row('Branch', data['branch'] ?? '-'),
                  _row('Year', data['year'] ?? '-'),
                  if ((data['company'] ?? '').toString().isNotEmpty) _row('Company', data['company']),
                ]),
              ),
              const SizedBox(height: 12),
              Container(
                decoration: AppTheme.shadowedCard,
                child: Column(children: [
                  ListTile(
                    leading: const Icon(Icons.notifications_outlined),
                    title: const Text('Notification settings'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.lock_outline),
                    title: const Text('Privacy'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.logout, color: Colors.red),
                    title: const Text('Sign out', style: TextStyle(color: Colors.red)),
                    onTap: () async {
                      await AuthService().signOut();
                      if (!context.mounted) return;
                      Navigator.pushAndRemoveUntil(context,
                          MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
                    },
                  ),
                ]),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _row(String k, dynamic v) => ListTile(
        title: Text(k, style: const TextStyle(color: AppTheme.textMuted, fontSize: 13)),
        subtitle: Text('$v', style: const TextStyle(color: AppTheme.textDark, fontSize: 16)),
      );
}
