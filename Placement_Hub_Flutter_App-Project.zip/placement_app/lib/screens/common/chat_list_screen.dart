import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/chat_service.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/empty_state.dart';
import 'chat_screen.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final me = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Chats')),
      body: StreamBuilder<QuerySnapshot>(
        stream: ChatService().chatList(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const EmptyState(icon: Icons.chat_bubble_outline, title: 'No chats yet',
                subtitle: 'Connect with someone to start chatting');
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final m = docs[i].data() as Map<String, dynamic>;
              final parts = List<String>.from(m['participants'] ?? []);
              final other = parts.firstWhere((p) => p != me, orElse: () => me);
              return FutureBuilder<DocumentSnapshot>(
                future: FirestoreService().getUser(other),
                builder: (context, us) {
                  final u = (us.data?.data() as Map<String, dynamic>?) ?? {};
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: AppTheme.shadowedCard,
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: AppTheme.primary.withOpacity(0.1),
                        child: Text((u['name'] ?? 'U').toString()[0].toUpperCase(),
                            style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
                      ),
                      title: Text(u['name'] ?? 'User', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(m['lastMessage'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => ChatScreen(otherUid: other, otherName: u['name'] ?? 'User'),
                      )),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
