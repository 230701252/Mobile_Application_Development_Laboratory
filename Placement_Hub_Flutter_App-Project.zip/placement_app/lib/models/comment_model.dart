import 'package:cloud_firestore/cloud_firestore.dart';

class CommentModel {
  final String id;
  final String userId;
  final String userName;
  final String text;
  final Timestamp createdAt;

  CommentModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.text,
    required this.createdAt,
  });

  factory CommentModel.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>;
    return CommentModel(
      id: d.id,
      userId: m['userId'] ?? '',
      userName: m['userName'] ?? '',
      text: m['text'] ?? '',
      createdAt: m['createdAt'] ?? Timestamp.now(),
    );
  }
}
