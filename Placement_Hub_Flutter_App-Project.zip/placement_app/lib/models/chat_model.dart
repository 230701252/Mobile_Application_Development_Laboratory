import 'package:cloud_firestore/cloud_firestore.dart';

class ChatMessage {
  final String id;
  final String senderId;
  final String text;
  final Timestamp createdAt;

  ChatMessage({required this.id, required this.senderId, required this.text, required this.createdAt});

  factory ChatMessage.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>;
    return ChatMessage(
      id: d.id,
      senderId: m['senderId'] ?? '',
      text: m['text'] ?? '',
      createdAt: m['createdAt'] ?? Timestamp.now(),
    );
  }
}
