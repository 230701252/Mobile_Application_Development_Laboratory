import 'package:cloud_firestore/cloud_firestore.dart';

class MaterialModel {
  final String id;
  final String title;
  final String description;
  final String fileUrl;
  final String fileName;
  final String uploaderId;
  final String uploaderName;
  final String company;
  final List<String> tags;
  final List<String> likes;
  final int commentCount;
  final Timestamp createdAt;

  MaterialModel({
    required this.id,
    required this.title,
    required this.description,
    required this.fileUrl,
    required this.fileName,
    required this.uploaderId,
    required this.uploaderName,
    required this.company,
    required this.tags,
    required this.likes,
    required this.commentCount,
    required this.createdAt,
  });

  factory MaterialModel.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>;
    return MaterialModel(
      id: d.id,
      title: m['title'] ?? '',
      description: m['description'] ?? '',
      fileUrl: m['fileUrl'] ?? '',
      fileName: m['fileName'] ?? '',
      uploaderId: m['uploaderId'] ?? '',
      uploaderName: m['uploaderName'] ?? '',
      company: m['company'] ?? '',
      tags: List<String>.from(m['tags'] ?? []),
      likes: List<String>.from(m['likes'] ?? []),
      commentCount: m['commentCount'] ?? 0,
      createdAt: m['createdAt'] ?? Timestamp.now(),
    );
  }
}
