import 'package:cloud_firestore/cloud_firestore.dart';

class ConnectRequest {
  final String id;
  final String fromId;
  final String fromName;
  final String toId;
  final String status; // pending / accepted / rejected
  final Timestamp createdAt;

  ConnectRequest({
    required this.id,
    required this.fromId,
    required this.fromName,
    required this.toId,
    required this.status,
    required this.createdAt,
  });

  factory ConnectRequest.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>;
    return ConnectRequest(
      id: d.id,
      fromId: m['fromId'] ?? '',
      fromName: m['fromName'] ?? '',
      toId: m['toId'] ?? '',
      status: m['status'] ?? 'pending',
      createdAt: m['createdAt'] ?? Timestamp.now(),
    );
  }
}
