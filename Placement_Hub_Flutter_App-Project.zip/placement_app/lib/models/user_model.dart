class UserModel {
  final String uid;
  final String name;
  final String email;
  final String role; // 'senior' or 'junior'
  final String? branch;
  final String? year;
  final String? company; // for seniors
  final String? bio;
  final String? photoUrl;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
    this.branch,
    this.year,
    this.company,
    this.bio,
    this.photoUrl,
  });

  factory UserModel.fromMap(String uid, Map<String, dynamic> m) => UserModel(
        uid: uid,
        name: m['name'] ?? '',
        email: m['email'] ?? '',
        role: m['role'] ?? 'junior',
        branch: m['branch'],
        year: m['year'],
        company: m['company'],
        bio: m['bio'],
        photoUrl: m['photoUrl'],
      );

  Map<String, dynamic> toMap() => {
        'name': name,
        'email': email,
        'role': role,
        'branch': branch,
        'year': year,
        'company': company,
        'bio': bio,
        'photoUrl': photoUrl,
      };
}
