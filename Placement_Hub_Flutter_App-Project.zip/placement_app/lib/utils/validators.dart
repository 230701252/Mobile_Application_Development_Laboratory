class Validators {
  static String? email(String? v) {
    if (v == null || v.isEmpty) return 'Email required';
    final r = RegExp(r'^[\w.+-]+@[\w-]+\.[\w.-]+$');
    return r.hasMatch(v) ? null : 'Invalid email';
  }

  static String? password(String? v) {
    if (v == null || v.length < 6) return 'Min 6 characters';
    return null;
  }

  static String? notEmpty(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Required' : null;
}
