import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  final _db = FirebaseFirestore.instance;

  String chatId(String a, String b) {
    final ids = [a, b]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  Stream<QuerySnapshot> messages(String otherUid) {
    final me = FirebaseAuth.instance.currentUser!.uid;
    return _db
        .collection('chats')
        .doc(chatId(me, otherUid))
        .collection('messages')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Future<void> sendMessage(String otherUid, String text) async {
    final me = FirebaseAuth.instance.currentUser!;
    final id = chatId(me.uid, otherUid);
    final chatRef = _db.collection('chats').doc(id);
    await chatRef.set({
      'participants': [me.uid, otherUid],
      'lastMessage': text,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    await chatRef.collection('messages').add({
      'senderId': me.uid,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot> chatList() {
    final me = FirebaseAuth.instance.currentUser!.uid;
    return _db
        .collection('chats')
        .where('participants', arrayContains: me)
        .orderBy('updatedAt', descending: true)
        .snapshots();
  }
}
