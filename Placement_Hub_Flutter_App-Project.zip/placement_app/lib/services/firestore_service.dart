import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final _db = FirebaseFirestore.instance;

  // ---------- Materials ----------
  Stream<QuerySnapshot> materialsStream() =>
      _db.collection('materials').orderBy('createdAt', descending: true).snapshots();

  Stream<QuerySnapshot> materialsByUser(String uid) =>
      _db.collection('materials').where('uploaderId', isEqualTo: uid).snapshots();

  Future<void> addMaterial(Map<String, dynamic> data) =>
      _db.collection('materials').add({...data, 'createdAt': FieldValue.serverTimestamp()});

  Future<void> toggleLike(String materialId, String uid) async {
    final ref = _db.collection('materials').doc(materialId);
    await _db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      final likes = List<String>.from(snap['likes'] ?? []);
      if (likes.contains(uid)) {
        likes.remove(uid);
      } else {
        likes.add(uid);
      }
      tx.update(ref, {'likes': likes});
    });
  }

  // ---------- Comments ----------
  Stream<QuerySnapshot> commentsStream(String materialId) => _db
      .collection('materials')
      .doc(materialId)
      .collection('comments')
      .orderBy('createdAt', descending: true)
      .snapshots();

  Future<void> addComment(String materialId, String text) async {
    final user = FirebaseAuth.instance.currentUser!;
    final ref = _db.collection('materials').doc(materialId);
    await ref.collection('comments').add({
      'userId': user.uid,
      'userName': user.displayName ?? 'User',
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
    await ref.update({'commentCount': FieldValue.increment(1)});
  }

  // ---------- Saves ----------
  Future<void> toggleSave(String materialId) async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final ref = _db.collection('users').doc(uid).collection('saved').doc(materialId);
    final snap = await ref.get();
    if (snap.exists) {
      await ref.delete();
    } else {
      await ref.set({'savedAt': FieldValue.serverTimestamp()});
    }
  }

  // ---------- Connect Requests ----------
  Future<void> sendRequest(String toId, String toName) async {
    final user = FirebaseAuth.instance.currentUser!;
    await _db.collection('requests').add({
      'fromId': user.uid,
      'fromName': user.displayName ?? 'User',
      'toId': toId,
      'toName': toName,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot> incomingRequests(String uid) => _db
      .collection('requests')
      .where('toId', isEqualTo: uid)
      .where('status', isEqualTo: 'pending')
      .snapshots();

  Future<void> respondRequest(String reqId, String fromId, String toId, bool accept) async {
    await _db.collection('requests').doc(reqId).update({'status': accept ? 'accepted' : 'rejected'});
    if (accept) {
      // create connection both ways
      await _db.collection('users').doc(fromId).collection('connections').doc(toId).set({
        'connectedAt': FieldValue.serverTimestamp(),
      });
      await _db.collection('users').doc(toId).collection('connections').doc(fromId).set({
        'connectedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Stream<QuerySnapshot> connections(String uid) =>
      _db.collection('users').doc(uid).collection('connections').snapshots();

  Future<DocumentSnapshot> getUser(String uid) => _db.collection('users').doc(uid).get();
}
