import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:dio/dio.dart';

class StorageService {
  final _storage = FirebaseStorage.instance;

  Future<Map<String, String>> uploadPdf(File file, String uploaderId) async {
    final fileName = file.path.split('/').last;
    final ref = _storage.ref('materials/$uploaderId/${DateTime.now().millisecondsSinceEpoch}_$fileName');
    final task = await ref.putFile(file);
    final url = await task.ref.getDownloadURL();
    return {'url': url, 'name': fileName};
  }

  Future<File> downloadPdf(String url, String fileName) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/$fileName';
    await Dio().download(url, path);
    return File(path);
  }
}
