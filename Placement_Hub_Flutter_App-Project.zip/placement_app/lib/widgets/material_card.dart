import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/material_model.dart';
import '../theme/app_theme.dart';
import '../services/firestore_service.dart';

class MaterialCard extends StatelessWidget {
  final MaterialModel material;
  final VoidCallback onTap;
  const MaterialCard({super.key, required this.material, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final liked = material.likes.contains(uid);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.shadowedCard,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.picture_as_pdf, color: AppTheme.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(material.title,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      Text('${material.uploaderName} • ${material.company}',
                          style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(material.description,
                maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppTheme.textDark, height: 1.4)),
            const SizedBox(height: 12),
            Row(
              children: [
                _IconStat(
                  icon: liked ? Icons.favorite : Icons.favorite_border,
                  color: liked ? Colors.red : AppTheme.textMuted,
                  count: material.likes.length,
                  onTap: () => FirestoreService().toggleLike(material.id, uid),
                ),
                const SizedBox(width: 16),
                _IconStat(
                  icon: Icons.chat_bubble_outline,
                  color: AppTheme.textMuted,
                  count: material.commentCount,
                  onTap: onTap,
                ),
                const Spacer(),
                if (material.tags.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.background,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Text(material.tags.first,
                        style: const TextStyle(fontSize: 11, color: AppTheme.textMuted)),
                  ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class _IconStat extends StatelessWidget {
  final IconData icon;
  final Color color;
  final int count;
  final VoidCallback onTap;
  const _IconStat({required this.icon, required this.color, required this.count, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(children: [
        Icon(icon, size: 18, color: color),
        const SizedBox(width: 4),
        Text('$count', style: const TextStyle(color: AppTheme.textMuted, fontSize: 13)),
      ]),
    );
  }
}
