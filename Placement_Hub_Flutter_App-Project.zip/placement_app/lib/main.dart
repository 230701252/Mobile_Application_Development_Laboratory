import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'theme/app_theme.dart';
import 'screens/splash_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/senior/senior_home.dart';
import 'screens/junior/junior_home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // After running `flutterfire configure`, replace the line below with:
  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await Firebase.initializeApp();
  runApp(const PlacementHubApp());
}

class PlacementHubApp extends StatelessWidget {
  const PlacementHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Placement Hub',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
      routes: {
        '/login': (_) => const LoginScreen(),
        '/signup': (_) => const SignupScreen(),
        '/senior_home': (_) => const SeniorHome(),
        '/junior_home': (_) => const JuniorHome(),
      },
    );
  }
}

/// Helper: Resolve the current user's role from Firestore and route accordingly.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const LoginScreen();
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(user.uid).get(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final role = (snap.data!.data() as Map<String, dynamic>?)?['role'] ?? 'junior';
        return role == 'senior' ? const SeniorHome() : const JuniorHome();
      },
    );
  }
}
